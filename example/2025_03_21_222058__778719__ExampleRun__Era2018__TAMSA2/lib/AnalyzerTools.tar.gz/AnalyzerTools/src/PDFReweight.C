#include "PDFReweight.h"

PDFReweight::PDFReweight(){

}

PDFReweight::~PDFReweight(){

}
